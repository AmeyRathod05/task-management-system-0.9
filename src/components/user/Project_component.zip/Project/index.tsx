'use client';

import React, { useState, useMemo, useEffect, useCallback, useRef } from 'react';
import projectService from '@/services/projectService';
import { Project as ProjectType } from '@/types/project';
import ProjectsTable from './ProjectsTable';
import AddProjectForm from './AddProjectForm';
import ProjectKanbanBoard from './ProjectKanbanBoard';
import ProjectGanttChart from './ProjectGanttChart';
import { AngleDownIcon, CloseIcon } from '@/icons';
import PaginationWithIcon from '@/components/tables/DataTables/TableOne/PaginationWithIcon';
import Button from '@/components/ui/button/Button';
import Notification from '@/components/ui/notification/Notification';
import EditableProjectsTable from './EditableProjectsTable';
import { ProjectClientView } from './views/client/project/ProjectClientView';
import { useClientOnly, isServer } from '@/hooks/useSSR';
// Using CSS transitions for the slide-in panel

interface SlideInPanelProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}

// SlideInPanel component for the add/edit project form
const SlideInPanel = ({ isOpen, onClose, title, subtitle, children }: SlideInPanelProps) => {
  const panelRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  // Handle mount/unmount and animation states
  useEffect(() => {
    if (isOpen) {
      setIsMounted(true);
      // Small delay to allow for CSS transition
      const timer = setTimeout(() => setIsVisible(true), 10);
      return () => clearTimeout(timer);
    } else {
      setIsVisible(false);
      // Wait for the animation to complete before unmounting
      const timer = setTimeout(() => setIsMounted(false), 300);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Handle click outside to close and body scroll
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    if (isOpen) {
      // Disable body scroll when panel is open
      document.body.style.overflow = 'hidden';
      document.body.style.paddingRight = '15px'; // Prevent content shift when scrollbar disappears
      document.addEventListener('mousedown', handleClickOutside);
      setIsVisible(true);
    } else {
      // Re-enable body scroll when panel is closed
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
      setIsVisible(false);
    }

    // Cleanup function
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.body.style.overflow = '';
      document.body.style.paddingRight = '';
    };
  }, [isOpen, onClose]);

  if (!isMounted) return null;

  // Use a portal to render the overlay and panel at the root level
  return (
    <>
      {/* Full-screen overlay that covers everything including sidebar */}
      <div 
        className={` mb-0 fixed inset-0 bg-black/75 z-[100000] transition-opacity duration-300 ${
          isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
        aria-hidden="true"
      />
      
      {/* Panel - positioned at the root level */}
      <div
        ref={panelRef}
        className={`fixed top-0 right-0 h-screen w-full max-w-2xl bg-white shadow-2xl z-[100001] overflow-y-auto transition-transform duration-300 ease-in-out transform ${
          isVisible ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="p-8 h-full overflow-y-auto">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{title}</h2>
              {subtitle && <p className="text-sm text-gray-500 mt-1">{subtitle}</p>}
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500 "
              aria-label="Close panel"
            >
              <CloseIcon className="text-gray-400 " />
            </button>
          </div>
          
          {/* Form Content */}
          <div className="space-y-6">
            {children}
          </div>
        </div>
      </div>
    </>
  );
};

// Debug SSR
console.log('Project component - Running on:', isServer ? 'server' : 'client');

type ViewType = 'list' | 'kanban' | 'gantt';

interface ProjectProps {
  initialProjects?: ProjectType[];
}

const Project: React.FC<ProjectProps> = ({ initialProjects = [] }) => {
  const isClient = useClientOnly();
  const [currentPage, setCurrentPage] = useState(1);
  const [sortKey, setSortKey] = useState<keyof ProjectType>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const [projects, setProjects] = useState<ProjectType[]>([]);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [editingProject, setEditingProject] = useState<ProjectType | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [showNotification, setShowNotification] = useState(false);
  const [notificationType, setNotificationType] = useState<'success' | 'error'>('success');
  const [notificationMessage, setNotificationMessage] = useState('');
  const [activeView, setActiveView] = useState<ViewType>('list');
  const [isAddPanelOpen, setIsAddPanelOpen] = useState(false);
  
  const handleAddProject = useCallback(() => {
    setEditingProject(null);
    setIsAddPanelOpen(true);
  }, []);

  const handleEditProject = useCallback((project: ProjectType) => {
    setEditingProject(project);
    setIsAddPanelOpen(true);
  }, []);

  const handleClosePanel = useCallback(() => {
    setIsAddPanelOpen(false);
    setEditingProject(null);
  }, []);
  
  // Set initial data and handle client-side mounting
  useEffect(() => {
    console.log('Project component - Client-side mounted');
    
    // Set initial projects from server-side props
    if (initialProjects.length > 0) {
      console.log('Using server-side initial projects:', initialProjects.length);
      setProjects(initialProjects);
      setLoading(false);
      setIsInitialLoad(false);
      return;
    }
    
    // Only fetch if we don't have any data (fallback for direct client-side navigation)
    const fetchProjects = async () => {
      if (isInitialLoad && isClient) {
        try {
          setLoading(true);
          console.log('No server-side data, fetching projects from API...');
          const data = await projectService.getProjects();
          console.log('Projects fetched from client-side API:', data.length);
          setProjects(data);
        } catch (error) {
          console.error('Error fetching projects:', error);
          setError('Failed to load projects');
        } finally {
          setLoading(false);
          setIsInitialLoad(false);
        }
      }
    };
    
    fetchProjects();
    
    return () => {
      console.log('Project component - Client-side unmounting');
    };
  }, [isClient, initialProjects]);

  const filteredAndSortedData = useMemo(() => {
    return projects
      .filter((item) =>
        Object.values(item).some(
          (value) =>
            typeof value === 'string' &&
            value.toLowerCase().includes(searchTerm.toLowerCase())
        )
      )
      .sort((a, b) => {
        const aValue = a[sortKey];
        const bValue = b[sortKey];
        return sortOrder === 'asc'
          ? String(aValue).localeCompare(String(bValue))
          : String(bValue).localeCompare(String(aValue));
      });
  }, [sortKey, sortOrder, searchTerm, projects]);

  const totalItems = filteredAndSortedData.length;
  const itemsPerPage = 10; // Fixed at 10 items per page
  const totalPages = Math.ceil(totalItems / itemsPerPage);

  const handleSort = (key: keyof ProjectType) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortOrder('asc');
    }
  };


  const handleUpdateProject = async (id: string, data: Partial<ProjectType>) => {
    try {
      setIsSaving(true);
      const updatedProject = await projectService.updateProject(id, data);
      setProjects(prev => prev.map(p => p.id === id ? updatedProject : p));
      setNotificationType('success');
      setNotificationMessage('Project updated successfully');
      setShowNotification(true);
      return true;
    } catch (error) {
      console.error('Error updating project:', error);
      setNotificationType('error');
      setNotificationMessage('Failed to update project');
      setShowNotification(true);
      return false;
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string): Promise<boolean> => {
    console.log(`Delete project with ID: ${id}`);
    if (!window.confirm('Are you sure you want to delete this project?')) {
      return false;
    }
    
    try {
      setIsSaving(true);
      // Call API to delete the project
      await projectService.deleteProject(id);
      // Update local state after successful API call
      const updatedProjects = projects.filter((project) => project.id !== id);
      setProjects(updatedProjects);
      setNotificationType('success');
      setNotificationMessage('Project deleted successfully');
      setShowNotification(true);
      return true;
    } catch (error) {
      console.error('Error deleting project:', error);
      setNotificationType('error');
      setNotificationMessage('Failed to delete project');
      setShowNotification(true);
      return false;
    } finally {
      setIsSaving(false);
    }
  };

  const handleSave = async (formData: ProjectType) => {
    try {
      setIsSaving(true);
      let updatedProject: ProjectType;

      if (editingProject && editingProject.id) {
        updatedProject = await projectService.updateProject(editingProject.id, formData);
        setProjects(prev => prev.map(p => p.id === editingProject.id ? updatedProject : p));
        setNotificationType('success');
        setNotificationMessage('Project updated successfully');
      } else {
        updatedProject = await projectService.createProject(formData);
        setProjects(prev => [...prev, updatedProject]);
        setNotificationType('success');
        setNotificationMessage('Project created successfully');
      }

      setShowNotification(true);
      setIsAddPanelOpen(false);
      return true;
    } catch (error) {
      console.error('Error saving project:', error);
      setNotificationType('error');
      setNotificationMessage(editingProject ? 'Failed to update project' : 'Failed to create project');
      setShowNotification(true);
      return false;
    } finally {
      setIsSaving(false);
      setEditingProject(null);
    }
  };

  const handleStatusChange = async (projectId: string, newStatus: string): Promise<boolean> => {
    try {
      setIsSaving(true);
      // Find the project to update
      const projectToUpdate = projects.find(p => p.id === projectId);
      
      if (!projectToUpdate) {
        console.error('Project not found:', projectId);
        return false;
      }
      
      // Ensure status is one of the allowed values
      const validStatus = (['active', 'completed', 'archived'] as const).includes(
        newStatus.toLowerCase() as 'active' | 'completed' | 'archived'
      ) ? newStatus.toLowerCase() as 'active' | 'completed' | 'archived' : 'active';
      
      // Create updated project with new status
      const updatedProject: ProjectType = {
        ...projectToUpdate,
        status: validStatus
      };
      
      // Call API to update the project
      const result = await projectService.updateProject(projectId, updatedProject);
      
      // Update local state with the response from the API
      setProjects(prev => prev.map(p => p.id === projectId ? result : p));
      
      setNotificationType('success');
      setNotificationMessage('Project status updated successfully');
      setShowNotification(true);
      return true;
    } catch (error) {
      console.error('Error updating project status:', error);
      setNotificationType('error');
      setNotificationMessage('Failed to update project status');
      setShowNotification(true);
      return false;
    } finally {
      setIsSaving(false);
    }
  };

  const handleNotification = (type: 'success' | 'error', message: string) => {
    setNotificationType(type);
    setNotificationMessage(message);
    setShowNotification(true);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const indexOfLastProject = currentPage * itemsPerPage;
  const indexOfFirstProject = indexOfLastProject - itemsPerPage;
  const currentProjects = filteredAndSortedData.slice(indexOfFirstProject, indexOfLastProject);

  // Handle project updates and refresh the list
  const handleProjectUpdated = useCallback((updatedProject: ProjectType) => {
    setProjects(prev => 
      prev.map(project => 
        project.id === updatedProject.id ? updatedProject : project
      )
    );
  }, []);

  // Handle project deletion
  const handleProjectDeleted = useCallback((deletedId: string) => {
    setProjects(prev => prev.filter(project => project.id !== deletedId));
  }, []);

  // Handle project creation
  const handleProjectCreated = useCallback((newProject: ProjectType) => {
    setProjects(prev => [newProject, ...prev]);
  }, []);
  
  const handleCloseAddPanel = useCallback(() => {
    setIsAddPanelOpen(false);
  }, []);

  const handleCreateProject = async (projectData: ProjectType) => {
    try {
      setLoading(true);
      const newProject = await projectService.createProject(projectData);
      if (newProject) {
        setProjects(prev => [newProject, ...prev]);
        setNotificationMessage('Project created successfully');
        setShowNotification(true);
      
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error creating project:', error);
      setNotificationMessage('Failed to create project');
      setShowNotification(true);
      return false;
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Project Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Projects</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Manage your projects and tasks efficiently
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            
            <input
              type="text"
              placeholder="Search projects..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center space-x-1">
              <Button
                variant={activeView === 'list' ? 'primary' : 'outline'}
                size="sm"
                onClick={() => setActiveView('list')}
                className="p-1.5"
                data-tooltip="List View"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                </svg>
              </Button>
              <Button
                variant={activeView === 'kanban' ? 'primary' : 'outline'}
                size="sm"
                onClick={() => setActiveView('kanban')}
                className="p-1.5"
                data-tooltip="Kanban View"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2" />
                </svg>
              </Button>
              <Button
                variant={activeView === 'gantt' ? 'primary' : 'outline'}
                size="sm"
                onClick={() => setActiveView('gantt')}
                className="p-1.5"
                data-tooltip="Gantt Chart View"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleAddProject}
                className="p-1.5"
                data-tooltip="Add Project"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                </svg>
              </Button>
            </div>
          </div>
        </div>

        {/* Notification Container - Fixed position with z-index to overlap header */}
        {(isSaving || showNotification) && (
          <div className="fixed top-4 right-4 z-50">
            <div className="flex items-center gap-2 text-sm text-gray-600 bg-white dark:bg-gray-800 shadow-lg rounded-lg px-4 py-2 border border-gray-200 dark:border-gray-700">
              {isSaving ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-brand-500 border-t-transparent"></div>
                  <span>Saving changes...</span>
                </div>
              ) : (
                <Notification
                  variant={notificationType}
                  title={notificationMessage}
                  hideDuration={3000}
                />
              )}
            </div>
          </div>
        )}
      </div>

      {/* View Content */}
      {activeView === 'list' && (
        <>
          <div className="mb-6">
            <ProjectClientView 
              initialData={currentProjects}
              onUpdate={handleProjectUpdated}
              onDelete={handleProjectDeleted}
              onCreate={handleCreateProject}
              onEdit={handleEditProject}
              onOpenAddModal={handleAddProject}
            />
          </div>

          <PaginationWithIcon
            totalPages={totalPages}
            initialPage={currentPage}
            onPageChange={handlePageChange}
          />

          {/* Add Project Slide-in Panel */}
          <SlideInPanel 
            isOpen={isAddPanelOpen} 
            onClose={handleClosePanel}
            title={editingProject ? 'Edit Project' : 'Create New Project'}
            subtitle={editingProject ? 'Update the project details below' : 'Fill in the details below to create a new project'}
          >
            <AddProjectForm 
              initialData={editingProject || undefined}
              onSave={async (projectData) => {
                try {
                  let success = false;
                  
                  if (editingProject && editingProject.id) {
                    // Update existing project
                    const updatedProject = await projectService.updateProject(editingProject.id, projectData);
                    setProjects(prev => prev.map(p => p.id === editingProject.id ? updatedProject : p));
                    setNotificationType('success');
                    setNotificationMessage('Project updated successfully');
                    success = true;
                  } else {
                    // Create new project
                    const newProject = await projectService.createProject(projectData);
                    setProjects(prev => [...prev, newProject]);
                    setNotificationType('success');
                    setNotificationMessage('Project created successfully');
                    success = true;
                  }
                  
                  setShowNotification(true);
                  handleClosePanel();
                  return success;
                } catch (error) {
                  console.error('Error saving project:', error);
                  setNotificationType('error');
                  setNotificationMessage(editingProject ? 'Failed to update project' : 'Failed to create project');
                  setShowNotification(true);
                  return false;
                }
              }}
              onClose={handleClosePanel}
              isSaving={isSaving}
            />
          </SlideInPanel>
        </>
      )}
      
      {activeView === 'kanban' && (
        <div className="bg-white rounded-lg shadow p-4">
          <ProjectKanbanBoard 
            projects={filteredAndSortedData} 
            onStatusChange={handleStatusChange}
            onNotification={(type, message) => {
              setNotificationType(type);
              setNotificationMessage(message);
              setShowNotification(true);
            }}
          />
        </div>
      )}
      
      {activeView === 'gantt' && (
        <div className="bg-white rounded-lg shadow p-4">
          <ProjectGanttChart 
            projects={filteredAndSortedData}
          />
        </div>
      )}

    </div>
  );
};


export default Project;
