// Drag and drop constants
export const PROJECT_TASK_TYPE = 'project-task';
