import React from 'react';
import { Table, TableBody, TableCell, TableHeader, TableRow } from '@/components/ui/table';
import { AngleDownIcon, AngleUpIcon, PencilIcon, TrashBinIcon } from '@/icons';
import { Project as ProjectType } from '@/types/project';

interface ProjectsTableProps {
  data: ProjectType[];
  sortKey: keyof ProjectType;
  sortOrder: 'asc' | 'desc';
  onSort: (key: keyof ProjectType) => void;
  onEdit?: (id: string | number) => void;
  onDelete?: (id: string | number) => void;
}

const columns: { key: keyof ProjectType; label: string; className?: string }[] = [
  { key: 'id', label: 'ID', className: 'whitespace-nowrap' },
  { key: 'name', label: 'Project Name' },
  { key: 'start_date', label: 'Start Date', className: 'whitespace-nowrap' },
  { key: 'end_date', label: 'End Date', className: 'whitespace-nowrap' },
  { key: 'created_at', label: 'Created At', className: 'whitespace-nowrap' },
];

const ProjectsTable: React.FC<ProjectsTableProps> = ({ data, sortKey, sortOrder, onSort, onEdit, onDelete }) => {
  return (
    <Table>
      <TableHeader className="border-t border-gray-100 dark:border-white/[0.05]">
        <TableRow>
          {columns.map(({ key, label }) => (
            <TableCell key={key} className="px-4 py-3 border border-gray-100 dark:border-white/[0.05]">
              <button
                type="button"
                className="flex items-center gap-1 cursor-pointer bg-transparent border-0 p-0 m-0 font-medium text-gray-700 text-theme-xs dark:text-gray-400"
                onClick={() => onSort(key)}
                style={{ outline: 'none' }}
              >
                {label}
                <span className="flex flex-col gap-0.5 ml-1">
                  <AngleUpIcon
                    className={`text-gray-300 dark:text-gray-700 ${sortKey === key && sortOrder === 'asc' ? 'text-brand-500' : ''}`}
                  />
                  <AngleDownIcon
                    className={`text-gray-300 dark:text-gray-700 ${sortKey === key && sortOrder === 'desc' ? 'text-brand-500' : ''}`}
                  />
                </span>
              </button>
            </TableCell>
          ))}
          <TableCell className="px-2 py-3 border border-gray-100 dark:border-white/[0.05]">
            <span className="font-medium text-gray-700 text-theme-xs dark:text-gray-400">Actions</span>
          </TableCell>
        </TableRow>
      </TableHeader>
      <TableBody>
        {data.map((item) => (
          <TableRow key={item.id}>
            <TableCell className="px-4 py-3 font-normal text-gray-800 border border-gray-100 dark:border-white/[0.05] dark:text-gray-400/90 text-theme-sm whitespace-nowrap">
              {item.id}
            </TableCell>
            <TableCell className="px-4 py-3 font-medium text-gray-800 border border-gray-100 dark:border-white/[0.05] dark:text-white/90 text-theme-sm">
              {item.name}
            </TableCell>
            <TableCell className="px-4 py-3 font-normal text-gray-800 border border-gray-100 dark:border-white/[0.05] dark:text-gray-400/90 text-theme-sm whitespace-nowrap">
              {item.start_date ? new Date(item.start_date).toLocaleDateString() : 'Not set'}
            </TableCell>
            <TableCell className="px-4 py-3 font-normal text-gray-800 border border-gray-100 dark:border-white/[0.05] dark:text-gray-400/90 text-theme-sm whitespace-nowrap">
              {item.end_date ? new Date(item.end_date).toLocaleDateString() : 'Not set'}
            </TableCell>
            <TableCell className="px-4 py-3 font-normal text-gray-800 border border-gray-100 dark:border-white/[0.05] dark:text-gray-400/90 text-theme-sm whitespace-nowrap">
              {new Date(item.created_at || '').toLocaleDateString()}
            </TableCell>
            <TableCell className="px-2 py-3 border border-gray-100 dark:border-white/[0.05] w-20">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onEdit && onEdit(item.id || '')}
                  className="p-1 text-gray-500 transition-colors rounded hover:bg-gray-100 hover:text-brand-500 dark:text-gray-400 dark:hover:bg-gray-800"
                >
                  <PencilIcon />
                </button>
                <button
                  onClick={() => onDelete && onDelete(item.id || '')}
                  className="p-1 text-gray-500 transition-colors rounded hover:bg-gray-100 hover:text-danger-500 dark:text-gray-400 dark:hover:bg-gray-800"
                >
                  <TrashBinIcon />
                </button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};

export default ProjectsTable;
